package com.example.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;


public class MainActivity extends AppCompatActivity {
    private TextView mTextViewResult;
    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextViewResult = findViewById(R.id.text_view);
        Button buttonParse = findViewById(R.id.button);

        mQueue = Volley.newRequestQueue(this);

        buttonParse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jsonParse();
            }
        });
    }

    private void jsonParse() {

        String url = "https://api.covid19api.com/summary";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("Countries");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject cntry = jsonArray.getJSONObject(i);

                                String CountryName = cntry.getString("Country");
                                if (CountryName.equals("India")) {
                                    int New_Confirmed= cntry.getInt("NewConfirmed");
                                    int T_Confirmed= cntry.getInt("TotalConfirmed");
                                    int N_deaths=cntry.getInt("NewDeaths");
                                    int T_deaths=cntry.getInt("TotalDeaths");
                                    int N_recover=cntry.getInt("NewRecovered");
                                    int T_recovered=cntry.getInt("TotalRecovered");
                                    String date=cntry.getString("Date");
                                    String  date2[]= date.split("T");
                                    //mTextViewResult.append("COUNTRY INDIA \n\n New Confirmed Cases:" + "\t"+String.valueOf(New_Confirmed) + "\n\n Total number of confirmed cases: " + String.valueOf(T_Confirmed)
                                                           //+ "\n\n New Deaths:"+"\t"+N_deaths+"\n\n Total Deaths:"+"\t"+T_deaths+"\n\n New Recovered:"+"\t"+N_recover+"\n\n Total Recovered:"+"\t"+T_recovered+"\n Date:"+"\t"+date2[0]+"\n\n Time:"+"\t"+date2[1]);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mQueue.add(request);
    }
}